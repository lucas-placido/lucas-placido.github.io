# Lucas — Portfólio (GitHub Pages + Jekyll)

## Publicar
1) Suba estes arquivos para um repositório público.
2) Em Settings → Pages, selecione `Deploy from a branch`, branch `main`, pasta `/root`.
3) Acesse a URL gerada.

## Novos projetos
Copie `projects/lakehouse-bsg.md`, edite o front matter e o conteúdo em Markdown.
Imagens e GIFs: `assets/images/`.
